package com.maz.controllers;

import java.util.List;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

@FacesConverter("themeConverter")
public class ThemeConverter implements Converter {

    @Override
    public Object getAsObject(FacesContext arg0, UIComponent arg1, String value) {
        if (value.trim().equals("")) {
            return null;
        } else {
            try {
                int number = Integer.parseInt(value);
                List<Theme> themes=new ThemeService().getThemes();
                for (Theme s : themes) {
                    if (s.getId() == number) {
                        return s;
                    }
                }

            } catch(NumberFormatException ex) {
                ex.printStackTrace();
            }
        }

        return null;
    }

    @Override
    public String getAsString(FacesContext arg0, UIComponent arg1, Object value) {
        if (value == null || value.equals("")) {
            return "";
        } else {
            return String.valueOf(((Theme) value).getId());
        }
    }

}
